import { useRouter } from 'next/router'

export default function Navbar() {
  const router = useRouter()
  const { locale } = router

  const changeLanguage = (e) => {
    const locale = e.target.value
    router.push(router.pathname, router.asPath, { locale })
  }

  return (
    <nav className="flex justify-between items-center p-4 bg-green-800 text-white">
      <h1 className="text-xl font-bold">TNRAT India</h1>
      
      <div className="flex gap-4 items-center">
        <a href="/about">About</a>
        <a href="/events">Events</a>
        <a href="/news">News</a>
        <a href="/contact">Contact</a>

        {/* 🌍 Language Switcher */}
        <select
          onChange={changeLanguage}
          value={locale}
          className="ml-4 p-1 rounded text-black"
        >
          <option value="en">English</option>
          <option value="hi">हिंदी</option>
          <option value="ur">اردو</option>
        </select>
      </div>
    </nav>
  )
}
