export default function Footer() {
  return (
    <footer className="bg-green-950 text-center py-6 mt-12">
      <p>© {new Date().getFullYear()} TNRAT India | All Rights Reserved</p>
    </footer>
  );
}