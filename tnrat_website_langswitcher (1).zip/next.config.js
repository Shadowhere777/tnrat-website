module.exports = {
  i18n: {
    locales: ['en', 'hi', 'ur'],
    defaultLocale: 'en',
  },
}